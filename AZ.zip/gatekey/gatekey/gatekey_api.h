int gatekey_open(char *path, char *authkey);
int gatekey_create(char *path, char *authkey_out);
void gatekey_setup(void);
